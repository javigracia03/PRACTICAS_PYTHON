
def pedirNombre():
    nombre = input("Como te llamas?")

    print(f"¡Hola {nombre}!")

pedirNombre()