

def operacion(n, m, o):

    print(((n+m)/(m*o))**2)

n= int(input("Dime un número"))
m= int(input("Dime un número"))
o=int(input("Dime un número"))

operacion(n,m,o)

