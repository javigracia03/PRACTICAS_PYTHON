

def suma(a,b):
   
    print(f"La suma de {a} y {b} es {a + b}")

a = 5
b = 6
suma(a, b)